package com.avaliacao.desafio2.service;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avaliacao.desafio2.entities.Aluno;
import com.avaliacao.desafio2.repositories.AlunoRepositories;

@Service
public class AlunoService {
    private final AlunoRepositories alunoRepositories;
    
    @Autowired
    public AlunoService(AlunoRepositories alunoRepositories) {
        this.alunoRepositories = alunoRepositories;
    }

    public List<Aluno> getAllAlunos() {
        return alunoRepositories.findAll();
    }

    public Aluno getAlunoById(Long id) {
        Optional<Aluno> aluno = alunoRepositories.findById(id);
        return aluno.orElse(null);
    }
    //Query Method 
    public List<Aluno> buscarAlunosPorCidade(String cidade) {
        return alunoRepositories.findByCidade(cidade); 
      }
    //Query Method 
    public List<Aluno> buscarAlunosPorNomeERenda(String nome, Double renda) {
        return alunoRepositories.findByNomeAndRenda(nome,renda); 
      }
    //Query Method 
    public List<Aluno> buscarAlunosPorNome(String nome) {
        return alunoRepositories.findByNome(nome); 
      }
  //Query Method 
    public List<Aluno> buscarCidadeERenda(String cidade, Double renda) {
        return alunoRepositories.findByCidadeAndRenda(cidade,renda); 
      }
  //@query
    public List<Aluno> findByNome(String nome) {
        return alunoRepositories.findByNome(nome);
    }
  //@query
    public List<Aluno> findByNomeCompletoLike(String nomeCompleto) {
        return alunoRepositories.findByNomeLike(nomeCompleto);
    }
   //@query
    public List<Aluno> findByTurmaId(Long turmaId) {
        return alunoRepositories.findByTurmaId(turmaId);
    }

    public Aluno salvarAluno(Aluno aluno) {
        return alunoRepositories.salvar(aluno);
    }

    public Aluno updateAluno(Long id, Aluno updatedAluno) {
        Optional<Aluno> existingAluno = alunoRepositories.findById(id);
        if (existingAluno.isPresente()) {
            updatedAluno.setId(id);
            return alunoRepositories.save(updatedAluno);
        }
        return null;
    }

    public boolean deleteAluno(Long id) {
        Optional<Aluno> existingAluno = alunoRepositories.findById(id);
        if (existingAluno.isPresente()) {
            alunoRepositories.deleteById(id);
            return true;
        }
        return false;
    }
}