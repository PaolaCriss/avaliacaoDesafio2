package com.avaliacao.desafio2.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avaliacao.desafio2.entities.Aluno;

public interface AlunoRepositories extends JpaRepository<Aluno, Long> {
	//Query Methods
	List<Aluno> findByCidade(String cidade);
	List<Aluno> findByRa(String ra);

}