package com.avaliacao.desafio2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avaliacao.desafio2.entities.Turma;

public interface TurmaRepositories extends JpaRepository<Turma, Long> {
}